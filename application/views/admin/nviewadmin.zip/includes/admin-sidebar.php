<div id="sidebar" class="navbar-collapse collapse">
  <?php $uri_query=$this->uri->segment(2);?>
   <!-- BEGIN Navlist -->
   <ul class="nav nav-list">
      <li class="<?php if($uri_query=='dashboard'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/dashboard');?>">
         <i class="fa fa-dashboard"></i>
         <span>Dashboard</span>
         </a>
      </li>
      <li class="<?php if($uri_query=='about'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/about');?>">
         <i class="fa fa-check-square-o"></i>
         <span>About Us</span>
         </a>
      </li>
	   <li class="<?php if($uri_query=='contact'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/contact');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Contact Info</span>
         </a>
      </li>
       <li class="<?php if($uri_query=='category'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/category');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Category</span>
         </a>
      </li> 
	  
    <!---   <li class="<?php if($uri_query=='gallery'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/gallery');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Gallery</span>
         </a>
      </li> --->
	  
    <li class="<?php if($uri_query=='product'||$uri_query=='view-products'||$uri_query=='view-product'){echo 'active';}?>">
         <a href="#" class="dropdown-toggle">
           <i class="fa fa-check-square-o"></i>
            <span>Services</span>
            <b class="arrow fa fa-angle-right"></b>
         </a>

         <!-- BEGIN Submenu -->
         <ul class="submenu">
            <li class="<?php if($uri_query=='product'){echo 'active';}?>"><a href="<?php echo base_url('admin/product');?>">Add Service</a></li>
            <li class="<?php if($uri_query=='view-products'){echo 'active';}?>"><a href="<?php echo base_url('admin/view-products');?>">View Services</a></li>
         </ul>
      <!-- END Submenu -->
       </li>
	   
	   
	 
      <li class="<?php if($uri_query=='reviews'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/reviews');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Reviews</span>
         </a>
      </li>  
	  
	  
	  
      <li class="<?php if($uri_query=='gallery'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/gallery');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Prototype Products
</span>
         </a>
      </li>  
	  
	  
      <li class="<?php if($uri_query=='slider'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/slider');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Slider</span>
         </a>
      </li>  
	  
	  <li class="<?php if($uri_query=='work'){echo 'active';}?>">
         <a href="<?php echo base_url('admin/work');?>">
         <i class="fa fa-check-square-o"></i>
         <span>Our Work</span>
         </a>
      </li>  
	  
	  
	  
   </ul>
   <!-- END Navlist -->
   <!-- BEGIN Sidebar Collapse Button -->
   <div id="sidebar-collapse" class="visible-lg">
      <i class="fa fa-angle-double-left"></i>
   </div>
   <!-- END Sidebar Collapse Button -->
</div>
