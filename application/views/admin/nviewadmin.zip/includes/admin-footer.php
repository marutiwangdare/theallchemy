<footer>
<p><?php echo date('Y');?> © Northtech Defense
.</p>
</footer>
<a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>